// This file redirects to the component in the components folder
import { GameSettingsWidget } from './components/GameSettingsWidget';
export default GameSettingsWidget;
